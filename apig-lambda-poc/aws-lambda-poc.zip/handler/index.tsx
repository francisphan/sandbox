import {WebClient} from '@slack/web-api';
import {serialize} from '../lib/utils';

const CHANNEL_ID = 'C016CL95Q5A';
const TOKEN = 'xoxb-1195766336951-1210512540066-PWSncxthjEB4Ll6ZHd51JsFj';

const web = new WebClient(TOKEN);

const sendMessage = async (message: string) => {
    // See: https://api.slack.com/methods/chat.postMessage
    const res = await web.chat.postMessage({ channel: CHANNEL_ID, text: message });

    // `res` contains information about the posted message
    console.log('Message sent: ', res.ts);
};

export const handler = async (event, context) => {
    console.log('## ENVIRONMENT VARIABLES: ' + serialize(process.env));
    console.log('## CONTEXT: ' + serialize(context));
    console.log('## EVENT: ' + serialize(event));
    await sendMessage('foobar');
}