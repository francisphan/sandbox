export const serialize = (object) => {
    return JSON.stringify(object, null, 4);
}